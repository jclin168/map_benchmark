# Report language

The report text and table labels use English. The writing follows ASD-STE100 rules for short and direct technical text.

This update changes report presentation only. Numerical data, process output, and measured source hashes are unchanged.

The source patch includes the English report generators. Measured C++ source files and the recorded runner are unchanged.
